﻿using Reverso1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Reverso1.Controllers
{
    public class ReverseoController : Controller
    {
        // GET: Reverso
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ReverseIt(string initialtext)
        {
            var rev = new Reverse(initialtext);
            return View(rev);
        }
    }
}