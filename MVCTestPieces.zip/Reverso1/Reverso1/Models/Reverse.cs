﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Reverso1.Models
{
    public class Reverse
    {
        private char[] reverseArr;
        private char[] initialArr;
        private string _reversed;
        private string _initial;

        public string InitialText
        {
            get
            {
                return _initial;
            }
            set
            {
                _initial = value;
                _reversed = ReverseAll(_initial);
            }
        }

        public string ReverseText
        {
            get
            {
                return _reversed;
            }
        }

        public Reverse(string initial)
        {
            _initial = initial;
            _reversed = ReverseAll(initial);
        }

        private string ReverseAll(string initial)
        {
            var l = initial.Length;
            reverseArr = new char[l];
            initialArr = new char[l];
            initialArr = initial.ToArray();
            reverseArr = initialArr;
            string result=null;
            List<String> lst = SplitToWords(initial);
            lst.ForEach(w =>
            {
                result += " " + ReverseWord(w);
            });

            return result;
        }

        private string ReverseWord(string word)
        {
            char[] result = null;
            char[] iword = null;

            if (!String.IsNullOrEmpty(word))
            {
                var l = word.Length;
                result = new char[l];
                iword = new char[l];
                iword = word.ToArray();

                for (var i = 0; i < l; i++)
                {
                    result[i] = iword[l - i-1];
                }
            }
            return new string(result);
        }

        private List<String> SplitToWords(string initial)
        {
            //assume I cant use split
            List<String> lst = new List<string>();
            var allwords = initial.ToArray(); //ensure it is big enough, but wastefull
            var sb = new StringBuilder();
            for (var i=0;i<=initial.Length-1;i++)
            {
                sb.Append(allwords[i]);
                if (allwords[i] == ' ' | i == initial.Length - 1)
                {
                    lst.Add(sb.ToString());
                    sb.Clear();
                }
            }

            return lst;
        }
    }
}