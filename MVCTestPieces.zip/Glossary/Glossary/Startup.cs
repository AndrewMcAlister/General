﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Glossary.Startup))]
namespace Glossary
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }

    }
}
