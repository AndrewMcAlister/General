﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Glossary.Models
{
    public class GlossaryItem
    {
        [Key]
        public int Id { get; set; }
        public string Term { get; set; }
        public string Description { get; set; }

        public bool IsValid(ref string message)
        {
            bool result = true;
            if(String.IsNullOrEmpty(Term))
            {
                result = false;
                message = "Term is not supplied";
            }
            if (String.IsNullOrEmpty(Description))
            {
                result = false;
                message+= $"Description is not supplied for term {Term}";
            }

            return result;
        }
    }
}