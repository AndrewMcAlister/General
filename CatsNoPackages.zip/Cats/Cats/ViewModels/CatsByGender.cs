﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cats.ViewModels
{
    public class CatsByGender
    {
        public ICollection<String> MaleOwnerCatNames { get; set; }
        public ICollection<String> FemaleOwnerCatNames { get; set; }

        public CatsByGender()
        {
            MaleOwnerCatNames = new List<String>();
            FemaleOwnerCatNames = new List<String>();
        }
    }
}