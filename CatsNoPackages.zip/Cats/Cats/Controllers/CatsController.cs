﻿using Cats.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using Cats.ViewModels;

namespace Cats.Controllers
{
    public class CatsController : Controller
    {
        // GET: Cats
        public async Task<ActionResult> Index()
        {
            var js = await GetCatsData();
            var all = JsonConvert.DeserializeObject<ICollection<Person>>(js.Data.ToString());
            var cbg = new CatsByGender();
            var ownerswithcats = all.Where(o => o.pets!=null && o.pets.Any(p => p.type == "Cat")).ToList();
            ownerswithcats.ForEach(owc =>
            {
                owc.pets.ToList().ForEach(p =>
                {
                    if (p.type=="Cat")
                    {
                        if (owc.gender == "Male")
                        {
                            cbg.MaleOwnerCatNames.Add(p.name);
                        }
                        else
                            cbg.FemaleOwnerCatNames.Add(p.name);
                    }
                });
            });
            return View(cbg);
        }

        // GET: Cats/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        private async Task<JsonResult> GetCatsData()
        {
            WebResponse wr = null;
            var r = WebRequest.Create("http://www.igeniusgroup.com/people.json");
            wr = await r.GetResponseAsync();
            string x = null;
            StreamReader sr;
            using (sr = new StreamReader(wr.GetResponseStream()))
            {
                x += sr.ReadLine();
            }
            return Json(x);
        }

    }
}
