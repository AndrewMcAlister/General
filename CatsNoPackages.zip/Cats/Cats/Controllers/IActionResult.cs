﻿namespace Cats.Controllers
{
    public interface IActionResult
    {
    }
}