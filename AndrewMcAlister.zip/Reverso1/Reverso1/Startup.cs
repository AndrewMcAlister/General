﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Reverso1.Startup))]
namespace Reverso1
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
