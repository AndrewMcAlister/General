﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Configuration;

namespace Glossary.Models
{
    public class GlossaryContext : DbContext
    {
        private string _connStr;

        public GlossaryContext()
        {
            _connStr = ConfigurationManager.ConnectionStrings["GlossaryConnection"].ConnectionString;
            base.Database.Connection.ConnectionString = _connStr;
        }

        public System.Data.Entity.DbSet<Glossary.Models.GlossaryItem> GlossaryItems { get; set; }
    }
}