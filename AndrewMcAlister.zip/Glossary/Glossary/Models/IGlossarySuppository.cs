﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace Glossary.Models
{
    public interface IGlossarySuppository
    {
        IEnumerable<GlossaryItem> GetAll();
        GlossaryItem GetByTerm(string term);
        GlossaryItem GetById(int id);
        string Add(GlossaryItem e);
        void Delete(int id);
        void SetModified(GlossaryItem e);
        Task<bool> SaveChangesAsync();
        void Dispose();
    }
}