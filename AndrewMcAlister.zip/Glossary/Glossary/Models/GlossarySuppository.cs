﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace Glossary.Models
{
    public class GlossarySuppository : IGlossarySuppository, IDisposable
    {
        private GlossaryContext _context;

        public GlossarySuppository()
        {
            _context = new GlossaryContext();
            //_context.Database.Connection.ConnectionString = ConfigurationManager.ConnectionStrings["GlossaryConnection"].ConnectionString;
        }

        public string Add(GlossaryItem e)
        {
            string message = "OK";
            if (e.IsValid(ref message))
                _context.GlossaryItems.Add(e);

            return message;
        }

        public IEnumerable<GlossaryItem> GetAll()
        {
            return _context.GlossaryItems;
        }

        public GlossaryItem GetByTerm(string term)
        {
            return _context.GlossaryItems.FirstOrDefault(p => p.Term.ToUpper() == term.ToUpper());
        }

        public GlossaryItem GetById(int id)
        {
            var gi= _context.GlossaryItems.FirstOrDefault(p => p.Id == id);
            return gi;
        }

        public void Delete(int id)
        {
            GlossaryItem gi = GetById(id);
            if (gi != null)
                _context.GlossaryItems.Remove(gi);

        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _context.SaveChangesAsync()) > 0;
        }

        public void SetModified(GlossaryItem e)
        {
            _context.Entry(e).State = EntityState.Modified;
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}