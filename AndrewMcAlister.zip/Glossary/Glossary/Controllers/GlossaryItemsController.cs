﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Glossary.Models;

namespace Glossary.Controllers
{
    public class GlossaryItemsController : Controller
    {
        private IGlossarySuppository repo = new GlossarySuppository();

        // GET: GlossaryItems
        public ActionResult Index()
        {
            var items = repo.GetAll().OrderBy(p=>p.Term).ToList();
            return View(items);
        }

        // GET: GlossaryItems/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GlossaryItem glossaryItem = repo.GetById(id.Value);
            if (glossaryItem == null)
            {
                return HttpNotFound();
            }
            return View(glossaryItem);
        }

        // GET: GlossaryItems/Create
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Create([Bind(Include = "Id,Term,Description")] GlossaryItem glossaryItem)
        {
            if (ModelState.IsValid)
            {
                repo.Add(glossaryItem);
                await repo.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return View(glossaryItem);
        }

        // GET: GlossaryItems/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GlossaryItem glossaryItem = repo.GetById(id.Value);
            if (glossaryItem == null)
            {
                return HttpNotFound();
            }
            return View(glossaryItem);
        }

        // POST: GlossaryItems/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit([Bind(Include = "Id,Term,Description")] GlossaryItem glossaryItem)
        {
            if (ModelState.IsValid)
            {
                repo.SetModified(glossaryItem);
                await repo.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return View(glossaryItem);
        }

        // GET: GlossaryItems/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            GlossaryItem glossaryItem = repo.GetById(id.Value);
            if (glossaryItem == null)
            {
                return HttpNotFound();
            }

            return View(glossaryItem);
        }

        // POST: GlossaryItems/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(int id)
        {
            GlossaryItem glossaryItem = repo.GetById(id);
            repo.Delete(id);
            await repo.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                repo.Dispose();
            }
        }
    }
}
